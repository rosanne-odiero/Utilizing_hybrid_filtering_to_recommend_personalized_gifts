<?php
    //Database Connection Parameters
    $conn  = new mysqli("localhost", "root", "", "coi");
    // $conn->query("DELETE FROM tbl_users WHERE user_id > 5");
    // $conn->query("ALTER TABLE tbl_users AUTO_INCREMENT = 6");

    //Number of records
    $noRecords = 456;


    //Returns the data that is used to be cleaned
    function openFile(){
        $csv_file = './AMSDATAFINAL.csv';
        $fh = fopen($csv_file,'r') 
            or die('Error occurred when open the file ' . $csv_file );
            
            // Each line in the file is converted into an individual array that we call $data
            // The items of the array are comma separated
        $data = array();
        while($rec = fgetcsv($fh,1000,",")){

            // Each individual array is being pushed into the nested array
            $data[] = $rec;
        }
        // Close the file
        fclose($fh);
        // unset($data[0]);
        return $data;
    }

    function insertUsers($conn,$data){
        $password = '$2y$10$OAlXPujv1jCXWePclFtaDuqm8Lko3AGHfvQfs3R3WNEYXXL7RwsLW';
        // $conn->autocommit(FALSE);
        $last_id = null;
        $sql = array();
        foreach ($data as $key => $idata) {
            $query = "INSERT INTO tbl_users(email,password,suspended) VALUES('$idata[9]','$password',0);";
            $result = $conn->query($query);
            if (!$result ) {
                $result->free();
                throw new Exception($conn->error);
            }
            $last_id = $conn->insert_id;
        }
       return $last_id;   
    }
    function populateUserId($data,$last_id,$noRecords){
        $firstItem = $last_id - $noRecords + 1;
        foreach ($data as $key => $value) {
            $data[$key][26] = $firstItem++;
           
        }
        return $data;
    }
    function insertStudentBioData($cleanedData){
        foreach ($cleanedData as $key => $value) {
            $query = "INSERT INTO tbl_studentbiodata(designation_id,firstname,surname,othernames,email_address1,
                        phone_number, postal_address,town_id, maritalstatus_id, nationality_id, country_id,
                        county_id, subcounty_id, dob, gender_id, nationaldocument_id, national_documenttype,
                        user_id, national_document, Admission_no) 
                        VALUES($data[$key][20],$data[$key][6],$data[$key][5],$data[$key][7],$data[$key][9],
                                $data[$key][8], $data[$key][11].$data[$key][12],$data[$key][20],)";
            echo "<pre>";
            echo var_dump($value);
            echo "</pre>";
        }
        
    }
    $data = openFile();
    // $last_id = insertUsers($conn,$data);
    $last_id = 461;
    //Fill the data array with the user ids
    $cleanedData = populateUserId($data,$last_id,$noRecords);
    
    //Insert into tbl_biodata
    insertStudentBioData($cleanedData);
?>