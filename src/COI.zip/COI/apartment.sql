CREATE DATABASE apartment;

use apartment;

CREATE TABLE user(Name varchar(255),Username varchar(255), Sec_Q varchar(255), Answer varchar(255),Password varchar(255));

CREATE TABLE rent(Day varchar(255), Month varchar(255), Year varchar(255), House_No varchar(255), Floor varchar(255), Unit varchar(255), Rent varchar(255), Electricity_Bill varchar(255), Gas_Bill varchar(255), Water_bill varchar(255), Other_Charges varchar(255), Total varchar(255), Status varchar(255));

