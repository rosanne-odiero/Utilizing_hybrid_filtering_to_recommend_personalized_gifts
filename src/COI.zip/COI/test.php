<?php
    //Database Connection Parameters
    $mysqli  = new mysqli("localhost", "root", "", "coi");
    $nationalityID = 113;
    $maritalStatusId = 2;
    $dob = "1998-09-09";
    $nationalDocument = "Pro_forma_Invoice2.pdf";
    $nationalDocumentType = 2;
    
    //Returns the data that is used to be cleaned
    function openFile(){
        $csv_file = './AMSDATA .csv';
        
        $fh = fopen($csv_file,'r') 
            or die('Error occurred when open the file ' . $csv_file );
            
            // Each line in the file is converted into an individual array that we call $data
            // The items of the array are comma separated
        $data = array();
        while($rec = fgetcsv($fh,1000,",")){

            // Each individual array is being pushed into the nested array
            $data[] = $rec;
        }
            
        // Close the file
        fclose($fh);
        unset($data[0]);

        return $data;
    }

    //Returns cleaned CSV
    function createCleanedCSV($data){
        // open csv file for write
        if (!file_exists('AMSDATAREFINED.csv')){
            $ff = fopen('AMSDATAREFINED.csv','w');
            
            foreach ($data as $rec) {
            fputcsv($ff, $rec);
            }
            fclose($ff);
        }
        
    }
    //Return SQL Seeder File
    function createUsersSeeder($data){
        $password = '$2y$10$OAlXPujv1jCXWePclFtaDuqm8Lko3AGHfvQfs3R3WNEYXXL7RwsLW';
        // open csv file for write
        if (!file_exists('users.sql')){
            $sql = array();
            $ff = fopen('users.sql','w');
            foreach ($data as $key => $idata) {
                for ($i=6; $i < 462 ; $i++) { 
                    array_push($sql,"INSERT INTO tbl_users(user_id,email,password) VALUES($i,'$idata[9]','$password');");
                }
            }
            $sSql = implode("\n",$sql);
            fwrite($ff,$sSql);
            fclose($ff);
        }
        
    }
    //Returns an array of the designations
    function getDesignations($mysqli){
        $sql = "SELECT designation_id,designation FROM tbl_designations";
        $sqlResult = $mysqli->query($sql);

        $result = array();
        foreach ($sqlResult as $key => $dd) {
            array_push($result,$dd);
        }
        return $result;
    }
    //Returns an array of the towns
    function getTownId($mysqli){
        $sql = "SELECT town_id,name FROM tbl_town";
        $sqlResult = $mysqli->query($sql);
        
        $result = array();
        foreach ($sqlResult as $key => $dd) {
            array_push($result,$dd);
        }
        return $result;
    }
    //Returns an array of marital status and their ID's
    function getMaritalStatus($mysqli){
        $sql = "SELECT maritalstatus_id,name FROM tbl_maritalstatus";
        $result = $mysqli->query($sql);
        $row = mysqli_fetch_array($result);
        return $row;
    }

    function getCountryID($mysqli){
        $sql = "SELECT country_id,name FROM tbl_countries";
        $result = $mysqli->query($sql);
        $row = mysqli_fetch_array($result);
        return $row;
    }

    function getCountyId($mysqli){
        $sql = "SELECT county_id,name FROM tbl_counties";
        $sqlResult = $mysqli->query($sql);
        
        $result = array();
        foreach ($sqlResult as $key => $dd) {
            array_push($result,$dd);
        }
        return $result;
    }
    
    function getSubCountyId($mysqli){
        $sql = "SELECT subcounty_id,county_id,subcounty FROM tbl_subcounties";
        $sqlResult = $mysqli->query($sql);
        
        $result = array();
        foreach ($sqlResult as $key => $dd) {
            array_push($result,$dd);
        }
        return $result;
    }

    function getGenderId($mysqli){
        $sql = "SELECT gender_id,gender FROM tbl_genders";
        $sqlResult = $mysqli->query($sql);
        $result = array();
        foreach ($sqlResult as $key => $dd) {
            array_push($result,$dd);
        }
        return $result;
    }

    function getNationalDocumentTypeId($mysqli){
        $sql = "SELECT nationaldoctype_id,name FROM tbl_nationaldoctype";
        $result = $mysqli->query($sql);
        $row = mysqli_fetch_array($result);
        return $row;
    }

    //Return SQL Seeder File For Student Biodata
    function filterForStudentBiodata($data,$nationalityID,$dob,$maritalStatusId,$nationalDocumentType,$nationalDocument){
        //Database Connection Parameters
        $mysqli  = new mysqli("localhost", "root", "", "coi");
        $designations = getDesignations($mysqli);
        $gender = getGenderId($mysqli);
        $towns = getTownId($mysqli);
        $subCounties = getSubCountyId($mysqli);
        $counties = getCountyId($mysqli);

        // echo "<pre>";
        // var_dump($subCounties);
        // echo "</pre>";
        
        foreach ($data as $key => $idata) {
            $data[$key][18] = $nationalityID;
            $data[$key][14] = $nationalityID;
            if ($idata[19] == "F") {
                $data[$key][19] = $gender[0]["gender_id"];
                $data[$key][20] = $designations[3]["designation_id"];
            }
            if($idata[19] == "M"){
                $data[$key][19] = $gender[1]["gender_id"];
                $data[$key][20] = $designations[1]["designation_id"];
            }
            
        }
        
        foreach ($data as $key => $value) {
            $searchTown = ucfirst(strtolower($value[13]));
            $searchTownOne = ucfirst(strtolower($value[17]));
            $rowIndex = array_search(ucfirst(strtolower($value[13])), array_column($towns, 'name'));
            $rowIndexOne = array_search($searchTownOne, array_column($towns, 'name'));
            $data[$key][13] = $towns[$rowIndex]['town_id'];
            $data[$key][17] = $towns[$rowIndexOne]['town_id'];
        }
        
        foreach ($data as $key => $value) {
            $searchTown = $value[13];
            $rowIndex = array_search($searchTown,array_column($subCounties, 'county_id'));
            $data[$key][21] = $subCounties[$rowIndex]['subcounty_id'];
            $data[$key][22] = $maritalStatusId;
            $data[$key][23] = $dob;
            $data[$key][24] = $nationalDocumentType;
            $data[$key][25] = $nationalDocument;
           
        }

        foreach ($data as $key => $value) {
            $array[0] = substr($data[$key][8], 0, 3);
            $array[1] = substr($data[$key][8], 3, 3);
            $array[2] = substr($data[$key][8], 6, 3);
            $data[$key][8] = "+254 ".implode("-",$array);
        }
       
        // echo "<pre>";
        // var_dump($data);
        // echo "</pre>";
        // open csv file for write
        // open csv file for write
        // if (!file_exists('AMSDATAFINAL.csv')){
            $ff = fopen('AMSDATAFINAL.csv','w');
            
            foreach ($data as $rec) {
            fputcsv($ff, $rec);
            }
            fclose($ff);
        // }
    }
    $data = openFile();

    $pCountry = "KENYA";

    foreach ($data as $key => $idata) {

        if (strlen($idata[11]) < 1 && strlen($idata[15]) < 1 ) {
           $data[$key][11] = "56928";
           $data[$key][15] = "56928";
        }
        if(strlen($idata[12]) < 1 && strlen($idata[16]) < 1){
            $data[$key][12] = "200";
            $data[$key][16] = "200";
        }
        if (strlen($idata[13]) < 1 && $idata[17] < 1) {
            $data[$key][13] = "NAIROBI";
            $data[$key][17] = "NAIROBI";
        }
        if (strlen($idata[14]) < 1 || strcmp($idata[14],$pCountry)!=0 || 
            strlen($idata[18]) < 1 || empty($idata[10])) {
            $data[$key][14] = "KENYA";
            $data[$key][18] = "KENYA";
        }
        if (strpbrk($idata[2], '1234567890') !== FALSE) {
            $data[$key][2] = "SELF";
        }
        if (strlen($idata[16]) < 1) {
            $data[$key][16] = "200";
        }

        echo "<pre>";
        // var_dump($idata[9]);
        echo "</pre>";
       
    }
    
    createCleanedCSV($data);
    createUsersSeeder($data);
    getDesignations($mysqli);
    filterForStudentBiodata($data,$nationalityID,$dob,$maritalStatusId,$nationalDocumentType,$nationalDocument);
   
   
   
    

?>